<?php
// This is an example of config.php
$dbhost = 'localhost';
$dbuser = 'nicholiae';
$dbpass = 'password';
$dbname = 'shaffertechsolns';
?>
